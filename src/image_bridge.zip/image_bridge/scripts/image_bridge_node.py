#!/usr/bin/env python3
"""
image_bridge_node.py

Subscribes to depth/color images, CameraInfo, OccupancyGrid and TF,
synchronises the image pair, and streams everything over a TCP socket
using pickle serialization.

Protocol (per message):
  [4 bytes big-endian uint32: payload length N][N bytes pickle payload]

Two message types are sent:

  ── "map" (sent once on first receive and whenever the map changes) ──
  {
      "type"  : "map",
      "stamp" : float,
      "map"   : {
          "data"       : bytes,        # int8 occupancy values
          "width"      : int,
          "height"     : int,
          "resolution" : float,        # m/cell
          "origin_x"   : float,        # metres
          "origin_y"   : float,        # metres
          "frame_id"   : str,
      },
  }

  ── "frame" (sent for each synchronised depth/colour pair) ──
  {
      "type"  : "frame",
      "stamp" : float,
      "color" : { "data": bytes, "height": int, "width": int,
                  "encoding": str, "step": int },
      "depth" : { "data": bytes, "height": int, "width": int,
                  "encoding": str, "step": int },
      "camera_info" : {               # None until received
          "P"       : list[float],     # 12 elements, row-major 3×4
          "K"       : list[float],     # 9 elements, row-major 3×3
          "width"   : int,
          "height"  : int,
          "frame_id": str,
      },
      "tf_cam_to_map" : {             # None if lookup fails
          "translation" : [x, y, z],   # metres
          "rotation"    : [x, y, z, w],# quaternion
          "parent_frame": str,
          "child_frame" : str,
      },
  }
"""

import pickle
import socket
import struct
import threading

import rospy
import tf2_ros
from sensor_msgs.msg import Image, CameraInfo
from nav_msgs.msg import OccupancyGrid
import message_filters
import numpy as np


class ImageBridgeNode:
    """TCP server that streams synchronised depth + colour frames
    together with camera intrinsics, TF and occupancy grid."""

    def __init__(self):
        rospy.init_node("image_bridge_node", anonymous=False)

        # ---- parameters ----
        self.tcp_host = rospy.get_param("~tcp_host", "0.0.0.0")
        self.tcp_port = rospy.get_param("~tcp_port", 9999)
        self.queue_size = rospy.get_param("~queue_size", 5)
        self.slop = rospy.get_param("~slop", 0.1)

        depth_topic = rospy.get_param(
            "~depth_topic",
            "/locobot/camera/aligned_depth_to_color/image_raw",
        )
        color_topic = rospy.get_param(
            "~color_topic",
            "/locobot/camera/color/image_raw",
        )
        camera_info_topic = rospy.get_param(
            "~camera_info_topic",
            "/locobot/camera/aligned_depth_to_color/camera_info",
        )
        map_topic = rospy.get_param(
            "~map_topic",
            "/locobot/octomap_server/projected_map",
        )
        self.map_frame = rospy.get_param("~map_frame", "map")

        # ---- cached state ----
        self.camera_info_dict = None        # serialisable dict
        self.camera_frame_id = None         # e.g. "locobot/camera_color_optical_frame"
        self._last_map_stamp = None         # used to detect map changes

        # ---- TF2 ----
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer)

        # ---- TCP server ----
        self.clients = []
        self.clients_lock = threading.Lock()

        self.server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_sock.settimeout(1.0)
        self.server_sock.bind((self.tcp_host, self.tcp_port))
        self.server_sock.listen(5)
        rospy.loginfo(
            "ImageBridge TCP server listening on %s:%d",
            self.tcp_host,
            self.tcp_port,
        )

        self.accept_thread = threading.Thread(target=self._accept_loop, daemon=True)
        self.accept_thread.start()

        # ---- ROS subscribers ----
        # CameraInfo (latched-style: cache once)
        rospy.Subscriber(
            camera_info_topic, CameraInfo, self._camera_info_cb, queue_size=1
        )

        # OccupancyGrid (send to clients on receive)
        rospy.Subscriber(
            map_topic, OccupancyGrid, self._map_cb, queue_size=1
        )

        # Synchronised depth + colour
        sub_depth = message_filters.Subscriber(depth_topic, Image)
        sub_color = message_filters.Subscriber(color_topic, Image)

        self.sync = message_filters.ApproximateTimeSynchronizer(
            [sub_depth, sub_color],
            queue_size=self.queue_size,
            slop=self.slop,
        )
        self.sync.registerCallback(self._image_cb)

        rospy.loginfo(
            "ImageBridge subscribed to:\n"
            "  depth : %s\n"
            "  color : %s\n"
            "  info  : %s\n"
            "  map   : %s",
            depth_topic,
            color_topic,
            camera_info_topic,
            map_topic,
        )

    # ================================================================== #
    # TCP helpers
    # ================================================================== #
    def _accept_loop(self):
        while not rospy.is_shutdown():
            try:
                client_sock, addr = self.server_sock.accept()
                client_sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                with self.clients_lock:
                    self.clients.append(client_sock)
                rospy.loginfo("ImageBridge: client connected from %s", addr)
            except socket.timeout:
                continue
            except OSError:
                break

    def _broadcast(self, data: bytes):
        """Send *data* to every connected client; drop broken ones."""
        frame = struct.pack(">I", len(data)) + data
        dead = []
        with self.clients_lock:
            for sock in self.clients:
                try:
                    sock.sendall(frame)
                except (BrokenPipeError, ConnectionResetError, OSError):
                    dead.append(sock)
            for sock in dead:
                self.clients.remove(sock)
                try:
                    sock.close()
                except OSError:
                    pass
                rospy.logwarn("ImageBridge: client disconnected")

    # ================================================================== #
    # CameraInfo callback
    # ================================================================== #
    def _camera_info_cb(self, msg: CameraInfo):
        """Cache camera intrinsics (received once)."""
        if self.camera_info_dict is not None:
            return  # already cached
        self.camera_frame_id = msg.header.frame_id
        self.camera_info_dict = {
            "P": list(msg.P),          # 12 floats
            "K": list(msg.K),          # 9 floats
            "width": msg.width,
            "height": msg.height,
            "frame_id": msg.header.frame_id,
        }
        rospy.loginfo(
            "ImageBridge: camera info cached (frame=%s, %dx%d)",
            msg.header.frame_id,
            msg.width,
            msg.height,
        )

    # ================================================================== #
    # OccupancyGrid callback
    # ================================================================== #
    def _map_cb(self, msg: OccupancyGrid):
        """Broadcast the occupancy grid whenever it is received / changes."""
        stamp = msg.header.stamp.to_sec()
        if self._last_map_stamp == stamp:
            return  # duplicate

        self._last_map_stamp = stamp

        map_payload = {
            "type": "map",
            "stamp": stamp,
            "map": {
                "data": bytes(np.array(msg.data, dtype=np.int8).tobytes()),
                "width": msg.info.width,
                "height": msg.info.height,
                "resolution": msg.info.resolution,
                "origin_x": msg.info.origin.position.x,
                "origin_y": msg.info.origin.position.y,
                "frame_id": msg.header.frame_id,
            },
        }

        data = pickle.dumps(map_payload, protocol=pickle.HIGHEST_PROTOCOL)
        self._broadcast(data)
        rospy.loginfo(
            "ImageBridge: map sent (%dx%d, res=%.3f)",
            msg.info.width,
            msg.info.height,
            msg.info.resolution,
        )

    # ================================================================== #
    # TF lookup helper
    # ================================================================== #
    def _lookup_tf(self, stamp):
        """Return camera→map transform dict, or None on failure."""
        if self.camera_frame_id is None:
            return None
        try:
            t = self.tf_buffer.lookup_transform(
                self.map_frame,
                self.camera_frame_id,
                stamp,
                rospy.Duration(0.1),
            )
            tr = t.transform.translation
            ro = t.transform.rotation
            return {
                "translation": [tr.x, tr.y, tr.z],
                "rotation": [ro.x, ro.y, ro.z, ro.w],
                "parent_frame": t.header.frame_id,
                "child_frame": t.child_frame_id,
            }
        except (
            tf2_ros.LookupException,
            tf2_ros.ConnectivityException,
            tf2_ros.ExtrapolationException,
        ) as exc:
            rospy.logwarn_throttle(5.0, "ImageBridge TF lookup failed: %s", exc)
            return None

    # ================================================================== #
    # Synchronised image callback
    # ================================================================== #
    def _image_cb(self, depth_msg: Image, color_msg: Image):
        with self.clients_lock:
            if not self.clients:
                return

        stamp = depth_msg.header.stamp

        payload = {
            "type": "frame",
            "stamp": stamp.to_sec(),
            "depth": {
                "data": bytes(depth_msg.data),
                "height": depth_msg.height,
                "width": depth_msg.width,
                "encoding": depth_msg.encoding,
                "step": depth_msg.step,
            },
            "color": {
                "data": bytes(color_msg.data),
                "height": color_msg.height,
                "width": color_msg.width,
                "encoding": color_msg.encoding,
                "step": color_msg.step,
            },
            "camera_info": self.camera_info_dict,      # None until first CameraInfo
            "tf_cam_to_map": self._lookup_tf(stamp),   # None on failure
        }

        data = pickle.dumps(payload, protocol=pickle.HIGHEST_PROTOCOL)
        self._broadcast(data)

    # ================================================================== #
    # Shutdown
    # ================================================================== #
    def shutdown(self):
        rospy.loginfo("ImageBridge: shutting down TCP server …")
        self.server_sock.close()
        with self.clients_lock:
            for s in self.clients:
                try:
                    s.close()
                except OSError:
                    pass
            self.clients.clear()


def main():
    node = ImageBridgeNode()
    rospy.on_shutdown(node.shutdown)
    rospy.spin()


if __name__ == "__main__":
    main()
