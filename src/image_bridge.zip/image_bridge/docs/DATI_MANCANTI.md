# Dati Mancanti per Riprodurre il Nodo ROS in Python Puro

## Stato Attuale
Il `client.py` attualmente riceve **immagini RGB e Depth** via TCP. Per riprodurre completamente il comportamento di `segment_live_node (REFERENCE).py`, servono le seguenti informazioni aggiuntive.

---

## 1. Parametri Intrinseci della Camera (OBBLIGATORIO)

Il nodo ROS usa la matrice di proiezione `P` dal topic `CameraInfo` per convertire pixel 2D → punti 3D.

**Parametri necessari:**
| Parametro | Descrizione |
|-----------|-------------|
| `fx` | Focal length X (pixel) |
| `fy` | Focal length Y (pixel) |
| `cx` | Principal point X (pixel) |
| `cy` | Principal point Y (pixel) |

**Come ottenerli:**
- Dal file di calibrazione della camera (es. `camera_info.yaml`)
- Dal topic ROS: `/locobot/camera/aligned_depth_to_color/camera_info`
- Comando ROS: `rostopic echo -n 1 /locobot/camera/aligned_depth_to_color/camera_info`

**Formato atteso (matrice P 3x4):**
```
P = [fx,  0, cx, 0,
      0, fy, cy, 0,
      0,  0,  1, 0]
```

---

## 2. Mappa di Sfondo / OccupancyGrid (OBBLIGATORIO per projected_map)

Il nodo ROS riceve una `OccupancyGrid` dal topic `/locobot/octomap_server/projected_map`.

**Opzioni:**
- **A) Immagine statica**: Fornire un'immagine PNG/JPG della mappa
- **B) Dati OccupancyGrid**: Inviare via TCP i metadati + dati griglia

**Metadati necessari:**
| Campo | Descrizione |
|-------|-------------|
| `width` | Larghezza mappa (pixel) |
| `height` | Altezza mappa (pixel) |
| `resolution` | Metri per pixel |
| `origin_x` | Origine X nel mondo (metri) |
| `origin_y` | Origine Y nel mondo (metri) |

**Come ottenerli:**
```bash
rostopic echo -n 1 /locobot/octomap_server/projected_map
```

---

## 3. Trasformazione Camera → Mondo (OBBLIGATORIO per projected_map)

Il nodo usa TF2 per trasformare i punti dal frame camera al frame "map".

**Opzioni:**
- **A) Camera fissa**: Fornire posizione e orientamento fissi
- **B) Camera mobile**: Inviare la posa via TCP ad ogni frame

**Dati necessari:**
| Campo | Descrizione |
|-------|-------------|
| `translation` | [x, y, z] in metri |
| `rotation` | Quaternion [x, y, z, w] |

**Come ottenerli:**
```bash
rosrun tf tf_echo map locobot/camera_color_optical_frame
```

---

## 4. Modelli di Segmentazione (OBBLIGATORIO)

### GroundingDINO
- **Config**: `GroundingDINO_SwinT_OGC.py`
- **Checkpoint**: `groundingdino_swint_ogc.pth`
- Repository: https://github.com/IDEA-Research/GroundingDINO

### LightHQSAM
- **Checkpoint**: `sam_hq_vit_tiny.pth`
- Repository: https://github.com/SysCV/sam-hq

**Alternativa più semplice:**
- Usare `segment-anything` ufficiale di Meta
- Usare YOLO per detection + SAM per segmentazione

---

## 5. Formato Immagine Depth (IMPORTANTE)

Verificare il formato depth inviato:
- **32FC1**: Valori float in **metri** (usato in Gazebo)
- **16UC1**: Valori uint16 in **millimetri** (usato da RealSense)

---

## Riepilogo Priorità

| # | Dato | Priorità | Per cosa serve |
|---|------|----------|----------------|
| 1 | Camera intrinsics | 🔴 Alta | Depth → 3D |
| 2 | Modelli ML | 🔴 Alta | Segmentazione |
| 3 | Mappa sfondo | 🟡 Media | Visualizzazione |
| 4 | TF camera→map | 🟡 Media | Proiezione su mappa |
| 5 | Formato depth | 🟢 Bassa | Conversione unità |

---

## Prossimi Passi

1. **Fornire i parametri camera** (`fx`, `fy`, `cx`, `cy`)
2. **Scaricare/configurare i modelli** GroundingDINO e SAM
3. **Decidere** se usare mappa statica o dinamica
4. **Decidere** se la camera è fissa o mobile

Una volta forniti questi dati, potrò creare la versione Python pura completa.
